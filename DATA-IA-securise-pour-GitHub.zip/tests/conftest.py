import os, tempfile
# Chaque exécution de tests utilise sa propre base, même si DB_PATH est défini
# dans l'environnement de la machine de développement.
os.environ["DB_PATH"] = tempfile.mktemp(prefix="data_ia_tests_", suffix=".db")
os.environ.pop("ANTHROPIC_API_KEY", None)
os.environ.pop("STRIPE_SECRET_KEY", None)
os.environ.pop("STRIPE_WEBHOOK_SECRET", None)
