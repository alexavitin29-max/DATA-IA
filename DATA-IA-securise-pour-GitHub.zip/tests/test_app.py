import os, io, tempfile
os.environ.setdefault("DB_PATH", tempfile.mktemp(suffix=".db")); os.environ["ALLOW_DEMO_UPGRADE"] = "1"
import pandas as pd
from fastapi.testclient import TestClient
from app import app
c = TestClient(app)
def auth(email="a@b.co"):
    t = c.post("/api/auth/signup", json={"email": email, "password": "motdepasse1"}).json()["token"]
    return {"Authorization": "Bearer " + t}
CSV = b"a,b,c\n1,2,x\n2,4,y\n3,6,y\n3,6,y\n"
def test_auth_required(): assert c.get("/api/me").status_code == 401
def test_bad_login(): assert c.post("/api/auth/login", json={"email": "z@z.co", "password": "x"}).status_code == 401
def test_csv_analysis():
    h = auth("csv@x.co"); r = c.post("/api/analyses", files=[("files", ("t.csv", CSV))], headers=h)
    s = r.json()["summaries"][0]; assert r.status_code == 200 and s["rows"] == 4 and s["duplicates"] == 1
    assert c.get(f"/api/analyses/{r.json()['id']}/report", headers=h).status_code == 200
def test_xlsx():
    b = io.BytesIO(); pd.DataFrame({"x": [1, 2]}).to_excel(b, index=False); h = auth("x@x.co")
    assert c.post("/api/analyses", files=[("files", ("t.xlsx", b.getvalue()))], headers=h).status_code == 200
def test_quota_and_limits():
    h = auth("q@x.co")
    for _ in range(3): assert c.post("/api/analyses", files=[("files", ("t.csv", CSV))], headers=h).status_code == 200
    assert c.post("/api/analyses", files=[("files", ("t.csv", CSV))], headers=h).status_code == 402
def test_multi_file_needs_business():
    h = auth("m@x.co"); f = [("files", ("1.csv", CSV)), ("files", ("2.csv", CSV))]
    assert c.post("/api/analyses", files=f, headers=h).status_code == 402
    import app as A; A._set_plan(A.db().execute("SELECT id FROM users WHERE email='m@x.co'").fetchone()[0], "business")
    assert c.post("/api/analyses", files=f, headers=h).status_code == 200
def test_bad_format():
    assert c.post("/api/analyses", files=[("files", ("t.exe", b"x"))], headers=auth("e@x.co")).status_code == 415

def test_failed_analysis_not_counted():
    h = auth("f@x.co"); c.post("/api/analyses", files=[("files", ("t.exe", b"x"))], headers=h)
    assert c.get("/api/me", headers=h).json()["used"] == 0
def test_source_is_local_without_key():
    os.environ.pop("ANTHROPIC_API_KEY", None); h = auth("s@x.co")
    r = c.post("/api/analyses", files=[("files", ("t.csv", CSV))], headers=h).json(); assert r["source"] == "local"
    a = c.post(f"/api/analyses/{r['id']}/ask", json={"question": "moyenne de a"}, headers=h).json(); assert a["source"] == "local" and "mean" in a["answer"]
def test_clean():
    h = auth("cl@x.co"); r = c.post("/api/clean?dedupe=true", files=[("file", ("t.csv", CSV))], headers=h)
    assert r.status_code == 200 and r.headers["x-removed-rows"] == "1"
