import io, pytest, pandas as pd
from fastapi.testclient import TestClient
import app as A
c = TestClient(A.app)
CSV = b"a,b,c\n1,2,x\n2,4,y\n3,6,y\n3,6,y\n100,7,z\n"
def signup(e):
    r = c.post("/api/auth/signup", json={"email": e, "password": "motdepasse1"}); assert r.status_code == 200
    return {"Authorization": "Bearer " + r.json()["token"]}
def uid(e): return A.db().execute("SELECT id FROM users WHERE email=?", (e,)).fetchone()[0]
def post(h, name="t.csv", data=CSV, **kw): return c.post("/api/analyses", files=[("files", (name, data))], headers=h, **kw)
def old_rows(e, n):
    with A.db() as d:
        for _ in range(n): d.execute("INSERT INTO analyses(user_id,team,created,names,summary,insights) VALUES(?,NULL,'2020-01-01T00:00:00','x','[]','{}')", (uid(e),))

def test_signup_login_rules():
    signup("s1@x.co")
    assert c.post("/api/auth/signup", json={"email": "s1@x.co", "password": "motdepasse1"}).status_code == 409
    assert c.post("/api/auth/signup", json={"email": "bad", "password": "motdepasse1"}).status_code == 422
    assert c.post("/api/auth/login", json={"email": "s1@x.co", "password": "motdepasse1"}).status_code == 200
def test_login_rate_limit():
    signup("s2@x.co")
    codes = [c.post("/api/auth/login", json={"email": "s2@x.co", "password": "faux"}).status_code for _ in range(6)]
    assert codes[:5] == [401] * 5 and codes[5] == 429
def test_invalid_files():
    h = signup("i@x.co")
    assert post(h, "a.exe", b"x").status_code == 415
    assert post(h, "a.xlsx", b"pas un zip").status_code == 415
    assert post(h, "a.csv", b"a\x00b\n").status_code == 415
    assert c.get("/api/me", headers=h).json()["used"] == 0
def test_too_large_not_counted():
    h = signup("big@x.co"); r = post(h, "big.csv", b"a\n" + b"1\n" * 1_100_000)
    assert r.status_code == 413 and c.get("/api/me", headers=h).json()["used"] == 0
def test_local_stats_and_outliers():
    h = signup("l@x.co"); r = post(h).json(); col = r["summaries"][0]["columns"][0]
    assert r["source"] == "local" and col["outliers"] == 1 and col["median"] == 3 and len(col["hist"]) == 8
def test_monthly_reset():
    h = signup("r@x.co"); old_rows("r@x.co", 3)
    assert c.get("/api/me", headers=h).json()["used"] == 0 and post(h).status_code == 200
def test_history_limit_free():
    h = signup("hl@x.co"); old_rows("hl@x.co", 12); assert len(c.get("/api/analyses", headers=h).json()) == 10
def test_ai_used_and_private(monkeypatch):
    seen = []; monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    monkeypatch.setattr(A, "call_ai", lambda p, s, n: seen.append(p) or "réponse IA")
    h = signup("ai@x.co"); r = post(h).json()
    assert r["source"] == "ai" and '"top"' not in seen[0] and "ai@x.co" not in seen[0]
    a = c.post(f"/api/analyses/{r['id']}/ask", json={"question": "tendance ?"}, headers=h).json()
    assert a["source"] == "ai"
def test_ai_failure_falls_back(monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "k")
    def boom(*a): raise RuntimeError
    monkeypatch.setattr(A, "call_ai", boom); assert post(signup("af@x.co")).json()["source"] == "local"
def test_ask_local():
    h = signup("ak@x.co"); i = post(h).json()["id"]
    a = c.post(f"/api/analyses/{i}/ask", json={"question": "moyenne de a"}, headers=h).json()
    assert a["source"] == "local" and "mean" in a["answer"]
def test_permissions_isolated():
    h1, h2 = signup("p1@x.co"), signup("p2@x.co"); i = post(h1).json()["id"]
    for u in (f"/api/analyses/{i}/report", f"/api/analyses/{i}/export?fmt=csv"): assert c.get(u, headers=h2).status_code == 404
    assert c.post(f"/api/analyses/{i}/ask", json={"question": "x"}, headers=h2).status_code == 404
    assert c.get(f"/api/analyses/{i}/report").status_code == 401 and c.get("/api/analyses").status_code == 401
def test_team_shared_history_and_join_limits():
    h1, h2 = signup("t1@x.co"), signup("t2@x.co"); A._set_plan(uid("t1@x.co"), "business")
    code = c.get("/api/me", headers=h1).json()["team"]; i = post(h1).json()["id"]
    assert c.post("/api/team/join/zzzz", headers=h2).status_code == 404
    assert c.post(f"/api/team/join/{code}", headers=h2).status_code == 200
    assert i in [x["id"] for x in c.get("/api/analyses", headers=h2).json()]
    assert c.get(f"/api/analyses/{i}/report", headers=h2).status_code == 200
def test_exports():
    h = signup("ex@x.co"); i = post(h).json()["id"]
    assert b"Colonne" in c.get(f"/api/analyses/{i}/export?fmt=csv", headers=h).content
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(c.get(f"/api/analyses/{i}/export?fmt=xlsx", headers=h).content)); assert "Conclusions" in wb.sheetnames
    assert c.get(f"/api/analyses/{i}/export?fmt=pdf", headers=h).content.startswith(b"%PDF")
    assert c.get(f"/api/analyses/{i}/export?fmt=zip", headers=h).status_code == 422
def test_clean_and_rate_limit():
    A._hits.clear(); h = signup("cl2@x.co")
    r = c.post("/api/clean", files=[("file", ("t.csv", CSV))], headers=h); assert r.status_code == 200 and r.headers["x-removed-rows"] == "1"
    r = c.post("/api/clean", files=[("file", ("t.csv", b"a\n=1+1\nx\n"))], headers=h); assert b"'=1+1" in r.content
    assert c.post("/api/clean?fmt=xlsx", files=[("file", ("t.csv", CSV))], headers=h).status_code == 200
    codes = [c.post("/api/clean", files=[("file", ("t.csv", CSV))], headers=h).status_code for _ in range(9)]
    assert codes[-1] == 429
def test_billing_not_simulated(monkeypatch):
    monkeypatch.delenv("STRIPE_SECRET_KEY", raising=False); h = signup("b@x.co")
    assert c.post("/api/billing/checkout/pro", headers=h).status_code == 503
    assert c.post("/api/me", json={"plan": "business"}, headers=h).status_code == 405
    assert c.get("/api/me", headers=h).json()["plan"] == "free"
    assert c.post("/api/billing/webhook", content=b"{}").status_code == 400
def test_headers_and_pwa():
    r = c.get("/"); assert "default-src 'self'" in r.headers["content-security-policy"]
    assert c.get("/manifest.webmanifest").status_code == 200 and c.get("/sw.js").status_code == 200
