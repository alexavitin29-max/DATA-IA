"""DATA IA - API FastAPI : auth, import CSV/Excel, analyse + IA, rapports, abonnements."""
import os, io, json, time, sqlite3, hashlib, secrets, html, zipfile
from datetime import datetime, timedelta, timezone
import jwt, pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Header, Request
from fastapi.responses import FileResponse, Response, JSONResponse
from pydantic import BaseModel

SECRET = os.getenv("SECRET_KEY", "dev-only-change-me-change-this-32-byte-key")
PROD = os.getenv("ENV") == "production"
if PROD and (not os.getenv("SECRET_KEY") or SECRET == "dev-only-change-me-change-this-32-byte-key"): raise RuntimeError("SECRET_KEY forte obligatoire en production")
MAX_BODY = 110 * 1024 * 1024
DB = os.getenv("DB_PATH", "data_ia.db")
PLANS = {  # analyses/mois, Mo max par fichier, fichiers par analyse, IA avancée
    "free": dict(analyses=3, mb=2, files=1, deep=False, clean=10),
    "pro": dict(analyses=100, mb=25, files=1, deep=True, clean=60),
    "business": dict(analyses=1000, mb=100, files=10, deep=True, clean=200),
}
app = FastAPI(title="DATA IA", version="1.0")

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE,
      pw TEXT, plan TEXT DEFAULT 'free', team TEXT, stripe_cust TEXT, lang TEXT DEFAULT 'fr');
      CREATE TABLE IF NOT EXISTS analyses(id INTEGER PRIMARY KEY, user_id INT, team TEXT,
      created TEXT, names TEXT, summary TEXT, insights TEXT);""")
    return c

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.scrypt(pw.encode(), salt=salt.encode(), n=2**14, r=8, p=1).hex()
def check_pw(pw, stored):
    return secrets.compare_digest(hash_pw(pw, stored.split("$")[0]), stored)

def token(uid):
    return jwt.encode({"sub": str(uid), "exp": datetime.now(timezone.utc) + timedelta(days=7)}, SECRET, "HS256")

def user(authorization: str = Header(None)):
    try:
        uid = int(jwt.decode((authorization or "").removeprefix("Bearer "), SECRET, ["HS256"])["sub"])
    except Exception:
        raise HTTPException(401, "Session invalide / Invalid session")
    row = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not row: raise HTTPException(401, "Utilisateur inconnu")
    return dict(row)

class Cred(BaseModel):
    email: str
    password: str

@app.post("/api/auth/signup")
def signup(c: Cred):
    if "@" not in c.email or len(c.password) < 8:
        raise HTTPException(422, "Email invalide ou mot de passe < 8 caractères")
    try:
        with db() as d:
            cur = d.execute("INSERT INTO users(email,pw) VALUES(?,?)", (c.email.lower(), hash_pw(c.password)))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Compte déjà existant")
    return {"token": token(cur.lastrowid)}

_tries = {}
@app.post("/api/auth/login")
def login(c: Cred):
    k = c.email.lower(); n, t = _tries.get(k, (0, 0))
    if n >= 5 and time.time() - t < 300: raise HTTPException(429, "Trop de tentatives, réessayez dans 5 min")
    r = db().execute("SELECT * FROM users WHERE email=?", (k,)).fetchone()
    if not r or not check_pw(c.password, r["pw"]):
        _tries[k] = (n + 1, time.time()); raise HTTPException(401, "Identifiants incorrects")
    _tries.pop(k, None); return {"token": token(r["id"])}

def used(u):
    m = datetime.now(timezone.utc).strftime("%Y-%m")
    return db().execute("SELECT COUNT(*) FROM analyses WHERE user_id=? AND created LIKE ?", (u["id"], m + "%")).fetchone()[0]

@app.get("/api/me")
def me(u=Depends(user)):
    p = PLANS[u["plan"]]
    return {"email": u["email"], "plan": u["plan"], "limits": p, "used": used(u), "remaining": max(0, p["analyses"] - used(u)), "reset": (datetime.now(timezone.utc).replace(day=1) + timedelta(days=32)).replace(day=1).strftime("%Y-%m-%d"), "team": u["team"]}

def read_df(name, raw):
    n = os.path.basename(name or "").lower()
    if n.endswith((".xlsx", ".xlsm")):
        if not raw.startswith(b"PK\x03\x04"): raise HTTPException(415, "Fichier Excel invalide")
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                if sum(i.file_size for i in z.infolist()) > 300 * 1024 * 1024: raise HTTPException(413, "Fichier Excel trop volumineux une fois décompressé")
        except zipfile.BadZipFile: raise HTTPException(415, "Fichier Excel invalide")
    elif n.endswith((".csv", ".txt")) and b"\x00" in raw[:8192]:
        raise HTTPException(415, "CSV invalide (contenu binaire)")
    if n.endswith((".xlsx", ".xlsm")): df = pd.read_excel(io.BytesIO(raw), engine="openpyxl")
    elif n.endswith((".csv", ".txt")):
        df = pd.read_csv(io.BytesIO(raw), sep=None, engine="python", encoding_errors="replace")
    else: raise HTTPException(415, f"{name}: format non supporté (.csv, .xlsx)")
    if df.empty: raise HTTPException(422, f"{name}: fichier vide")
    return df.head(500_000)

def profile(name, df):
    cols = []
    for c in df.columns:
        s = df[c]; info = {"name": str(c), "type": str(s.dtype), "missing": int(s.isna().sum())}
        if pd.api.types.is_numeric_dtype(s) and s.notna().any():
            q1, q3 = s.quantile(.25), s.quantile(.75); iqr = q3 - q1
            info.update(mean=round(float(s.mean()), 3), min=float(s.min()), max=float(s.max()),
                        std=round(float(s.std() or 0), 3), median=round(float(s.median()), 3),
                        outliers=int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum()),
                        hist=[int(x) for x in pd.cut(s.dropna(), bins=8).value_counts(sort=False)])
        else:
            info["top"] = {str(k): int(v) for k, v in s.astype(str).value_counts().head(3).items()}
        cols.append(info)
    num = df.select_dtypes("number")
    corr = []
    if num.shape[1] > 1:
        m = num.corr().abs().unstack().dropna()
        seen = set()
        for (a, b), v in m.sort_values(ascending=False).items():
            if a != b and (b, a) not in seen and len(corr) < 3:
                seen.add((a, b)); corr.append({"a": str(a), "b": str(b), "r": round(float(num[a].corr(num[b])), 3)})
    return {"file": name, "rows": len(df), "cols": len(df.columns), "duplicates": int(df.duplicated().sum()),
            "missing_total": int(df.isna().sum().sum()), "columns": cols, "correlations": corr}

def local_insights(S, lang):
    fr = lang == "fr"; out = []
    for s in S:
        out.append(f"{s['file']} : {s['rows']} lignes, {s['cols']} colonnes, {s['missing_total']} valeurs manquantes, {s['duplicates']} doublons."
                   if fr else f"{s['file']}: {s['rows']} rows, {s['cols']} columns, {s['missing_total']} missing values, {s['duplicates']} duplicates.")
        for c in s["columns"]:
            if c["missing"] > .2 * s["rows"]: out.append(f"- {c['name']} : {c['missing']} " + ("valeurs manquantes (>20 %)" if fr else "missing values (>20%)"))
            if c.get("outliers"): out.append(f"- {c['name']} : {c['outliers']} " + ("valeurs atypiques (méthode IQR)" if fr else "outliers (IQR method)"))
        for k in s["correlations"]:
            if abs(k["r"]) >= .7: out.append("- " + ("Corrélation " if fr else "Correlation ") + f"{k['a']}/{k['b']} : r={k['r']}")
    return "\n".join(out)

def for_ai(S):  # confidentialité : jamais de valeurs de cellules (top) envoyées à l'IA
    return [{**s, "columns": [{k: v for k, v in c.items() if k != "top"} for c in s["columns"]]} for s in S]

def call_ai(prompt, system, tokens):
    import anthropic
    r = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"]).messages.create(
        model=os.getenv("AI_MODEL", "claude-sonnet-5-5"), max_tokens=tokens, system=system,
        messages=[{"role": "user", "content": prompt}])
    return r.content[0].text

def ai_insights(summaries, lang, deep):
    """Retourne (texte, source) ; source = 'ai' seulement si une IA a réellement répondu."""
    if os.getenv("ANTHROPIC_API_KEY"):
        try:
            ask = ("Réponds en français." if lang == "fr" else "Answer in English.") + (
                " Analyse approfondie: anomalies, tendances, qualité, recommandations." if deep else " 4 observations clés courtes.")
            return call_ai(ask + "\n" + json.dumps(for_ai(summaries))[:30000],
                           "Analyste de données senior. Utilise uniquement les statistiques fournies, n'invente rien.", 1200 if deep else 500), "ai"
        except Exception:
            pass  # repli sur le moteur local
    return local_insights(summaries, lang), "local"

@app.post("/api/analyses")
async def analyze(files: list[UploadFile] = File(...), lang: str = "fr", u=Depends(user)):
    p = PLANS[u["plan"]]
    if used(u) >= p["analyses"]: raise HTTPException(402, "Quota mensuel atteint : passez à un plan supérieur")
    if len(files) > p["files"]: raise HTTPException(402, f"Plan {u['plan']} : {p['files']} fichier(s) max")
    summaries = []
    for f in files:
        raw = await f.read()
        if len(raw) > p["mb"] * 1024 * 1024: raise HTTPException(413, f"{f.filename} dépasse {p['mb']} Mo (plan {u['plan']})")
        try: df = read_df(f.filename or "", raw)
        except HTTPException: raise
        except Exception: raise HTTPException(422, f"{f.filename}: lecture impossible")
        summaries.append(profile(f.filename, df))
    ins, src = ai_insights(summaries, lang, p["deep"])
    with db() as d:
        cur = d.execute("INSERT INTO analyses(user_id,team,created,names,summary,insights) VALUES(?,?,?,?,?,?)",
            (u["id"], u["team"], datetime.now(timezone.utc).isoformat(), ", ".join(s["file"] for s in summaries),
             json.dumps(summaries), json.dumps({"text": ins, "source": src})))
    return {"id": cur.lastrowid, "summaries": summaries, "insights": ins, "source": src}

@app.get("/api/analyses")
def history(u=Depends(user)):
    q, a = "user_id=?", [u["id"]]
    if u["plan"] == "business" or u["team"]:
        q, a = "(user_id=? OR (team IS NOT NULL AND team=?))", [u["id"], u["team"]]
    rows = db().execute(f"SELECT id,created,names FROM analyses WHERE {q} ORDER BY id DESC LIMIT {50 if u['plan'] != 'free' else 10}", a).fetchall()
    return [dict(r) for r in rows]

@app.get("/api/analyses/{aid}/report")
def report(aid: int, fmt: str = "html", u=Depends(user)):
    r = db().execute("SELECT * FROM analyses WHERE id=? AND (user_id=? OR (team IS NOT NULL AND team=?))",
                     (aid, u["id"], u["team"])).fetchone()
    if not r: raise HTTPException(404, "Analyse introuvable")
    e = html.escape
    body = f"<h1>DATA IA — Rapport #{aid}</h1><p>{e(r['created'])} · {e(r['names'])}</p>"
    for s in json.loads(r["summary"]):
        body += f"<h2>{e(s['file'])}</h2><p>{s['rows']} lignes, {s['cols']} colonnes, {s['duplicates']} doublons, {s['missing_total']} manquants</p><table border=1 cellpadding=4><tr><th>Colonne<th>Type<th>Manquants<th>Moyenne<th>Min<th>Max"
        for c in s["columns"]:
            body += f"<tr><td>{e(c['name'])}<td>{c['type']}<td>{c['missing']}<td>{c.get('mean','')}<td>{c.get('min','')}<td>{c.get('max','')}"
        body += "</table>"
    try: ins = json.loads(r["insights"])
    except Exception: ins = {"text": r["insights"], "source": "local"}
    title = "Analyse générée par IA" if ins["source"] == "ai" else "Analyse statistique locale (sans IA)"
    body += f"<h2>{title}</h2><pre style='white-space:pre-wrap'>{e(ins['text'])}</pre>"
    return Response(f"<!doctype html><meta charset=utf-8><body style='font-family:sans-serif;max-width:800px;margin:2em auto'>{body}", media_type="text/html",
                    headers={"Content-Disposition": f'attachment; filename="rapport-{aid}.html"'} if fmt == "dl" else {})

def _ins(r):
    try: return json.loads(r["insights"])
    except Exception: return {"text": r["insights"], "source": "local"}

def _get(aid, u):
    r = db().execute("SELECT * FROM analyses WHERE id=? AND (user_id=? OR (team IS NOT NULL AND team=?))", (aid, u["id"], u["team"])).fetchone()
    if not r: raise HTTPException(404, "Analyse introuvable")
    return r

@app.get("/api/analyses/{aid}/export")
def export(aid: int, fmt: str = "csv", u=Depends(user)):
    r = _get(aid, u); S = json.loads(r["summary"]); ins = _ins(r)
    label = "Analyse générée par IA" if ins["source"] == "ai" else "Analyse statistique locale (sans IA)"
    head = ["Fichier", "Colonne", "Type", "Manquants", "Moyenne", "Médiane", "Min", "Max", "Atypiques"]
    sc = lambda v: "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v
    rows = [[sc(v) for v in [s["file"], c["name"], c["type"], c["missing"], c.get("mean", ""), c.get("median", ""), c.get("min", ""), c.get("max", ""), c.get("outliers", "")]]
            for s in S for c in s["columns"]]
    hd = {"Content-Disposition": f'attachment; filename="rapport-{aid}.{fmt}"'}
    if fmt == "csv":
        import csv; b = io.StringIO(); w = csv.writer(b); w.writerow(head); w.writerows(rows)
        return Response(b.getvalue().encode("utf-8-sig"), media_type="text/csv", headers=hd)
    if fmt == "xlsx":
        from openpyxl import Workbook
        wb = Workbook(); ws = wb.active; ws.title = "Résumé"; ws.append(["Analyse", aid]); ws.append(["Date", r["created"]])
        for s in S: ws.append([sc(s["file"]), f"{s['rows']} lignes", f"{s['cols']} colonnes", f"{s['duplicates']} doublons", f"{s['missing_total']} manquants"])
        w2 = wb.create_sheet("Colonnes"); w2.append(head)
        for x in rows: w2.append(x)
        w3 = wb.create_sheet("Conclusions"); w3.append([label])
        for l in ins["text"].split("\n"): w3.append(["'" + l if l[:1] == "=" else l])
        b = io.BytesIO(); wb.save(b); return Response(b.getvalue(), media_type=XLSX, headers=hd)
    if fmt == "pdf":
        from fpdf import FPDF
        p = FPDF(); p.add_page()
        def line(t, size=10, bold=False):
            p.set_font("Helvetica", "B" if bold else "", size)
            p.multi_cell(0, 6, str(t).encode("latin-1", "replace").decode("latin-1"), new_x="LMARGIN", new_y="NEXT")
        line(f"DATA IA - Rapport #{aid}", 16, True); line(f"{r['created'][:19]} - {r['names']}")
        for s in S:
            line(s["file"], 12, True); line(f"{s['rows']} lignes, {s['cols']} colonnes, {s['duplicates']} doublons, {s['missing_total']} valeurs manquantes")
            for c in s["columns"]:
                ex = "" if "mean" not in c else f", moy {c['mean']}, med {c['median']}, min {c['min']}, max {c['max']}, atypiques {c['outliers']}"
                line(f"- {c['name']} ({c['type']}) : {c['missing']} manquants{ex}", 9)
        line(label, 12, True); line(ins["text"])
        return Response(bytes(p.output()), media_type="application/pdf", headers=hd)
    raise HTTPException(422, "Format inconnu : csv, xlsx ou pdf")

@app.post("/api/team/join/{code}")
def join(code: str, u=Depends(user)):
    rate_limit(("join", u["id"]), 10)
    with db() as d:
        if not d.execute("SELECT 1 FROM users WHERE plan='business' AND team=?", (code,)).fetchone():
            raise HTTPException(404, "Code d'équipe invalide")
        d.execute("UPDATE users SET team=? WHERE id=?", (code, u["id"]))
    return {"team": code}

@app.post("/api/billing/checkout/{plan}")
def checkout(plan: str, u=Depends(user)):
    if plan not in ("pro", "business"): raise HTTPException(404, "Plan inconnu")
    key = os.getenv("STRIPE_SECRET_KEY")
    price = os.getenv(f"STRIPE_PRICE_{plan.upper()}")
    if not key or not price: raise HTTPException(503, "Paiement non configuré (STRIPE_SECRET_KEY et STRIPE_PRICE_*)")
    import stripe; stripe.api_key = key
    s = stripe.checkout.Session.create(mode="subscription", customer_email=u["email"], client_reference_id=str(u["id"]),
        line_items=[{"price": price, "quantity": 1}], metadata={"plan": plan},
        success_url=os.getenv("APP_URL", "") + "/?paid=1", cancel_url=os.getenv("APP_URL", ""))
    return {"url": s.url}

def _set_plan(uid, plan, cust=None):  # appelé uniquement par le webhook Stripe signé
    with db() as d:
        d.execute("UPDATE users SET plan=?, stripe_cust=COALESCE(?, stripe_cust), team=CASE WHEN ?='business' THEN ? ELSE team END WHERE id=?",
                  (plan, cust, plan, secrets.token_hex(4), uid))

@app.post("/api/billing/webhook")
async def webhook(req: Request):
    # Stripe peut ne pas être installé/configuré en développement : répondre proprement
    # au lieu de provoquer une erreur 500.
    try:
        import stripe
        signing_secret = os.getenv("STRIPE_WEBHOOK_SECRET")
        if not signing_secret:
            raise ValueError("Webhook Stripe non configuré")
        ev = stripe.Webhook.construct_event(
            await req.body(), req.headers.get("stripe-signature", ""), signing_secret
        )
    except Exception:
        raise HTTPException(400, "Signature invalide ou webhook Stripe non configuré")
    o = ev["data"]["object"]
    if ev["type"] == "checkout.session.completed": _set_plan(int(o["client_reference_id"]), o["metadata"]["plan"], o.get("customer"))
    if ev["type"] == "customer.subscription.deleted":
        with db() as d: d.execute("UPDATE users SET plan='free' WHERE stripe_cust=?", (o.get("customer"),))
    return {"ok": True}

_hits = {}
def rate_limit(key, n, per=3600):
    now = time.time(); h = [t for t in _hits.get(key, []) if now - t < per]
    if len(h) >= n: raise HTTPException(429, "Trop de requêtes, réessayez plus tard")
    h.append(now); _hits[key] = h

def safe(df):  # neutralise l'injection de formules dans Excel/CSV
    df = df.copy()
    for c in df.select_dtypes("object"):
        df[c] = df[c].map(lambda v: "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v)
    return df

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

@app.post("/api/clean")
async def clean(file: UploadFile = File(...), dedupe: bool = True, fill: str = "none", fmt: str = "csv", u=Depends(user)):
    rate_limit(("clean", u["id"]), PLANS[u["plan"]]["clean"])
    raw = await file.read()
    if len(raw) > PLANS[u["plan"]]["mb"] * 1048576: raise HTTPException(413, "Fichier trop volumineux pour votre plan")
    df = read_df(file.filename or "", raw); n0 = len(df)
    for c in df.select_dtypes("object"):  # espaces, vides, nombres écrits en texte ("1 234,5")
        df[c] = df[c].astype(str).str.strip().replace({"": None, "nan": None, "None": None})
        conv = pd.to_numeric(df[c].str.replace(" ", "").str.replace(",", ".", regex=False), errors="coerce")
        if df[c].notna().sum() and conv.notna().sum() >= .9 * df[c].notna().sum(): df[c] = conv
    if dedupe: df = df.drop_duplicates()
    if fill in ("median", "mode"):
        for c in df.columns:
            v = df[c].median() if fill == "median" and pd.api.types.is_numeric_dtype(df[c]) else (df[c].mode().iloc[0] if df[c].notna().any() else None)
            if v is not None: df[c] = df[c].fillna(v)
    ext = "xlsx" if fmt == "xlsx" else "csv"; out = safe(df)
    hd = {"X-Removed-Rows": str(n0 - len(df)), "Content-Disposition": f'attachment; filename="nettoye.{ext}"'}
    if ext == "xlsx":
        b = io.BytesIO(); out.to_excel(b, index=False); return Response(b.getvalue(), media_type=XLSX, headers=hd)
    return Response(out.to_csv(index=False).encode("utf-8-sig"), media_type="text/csv", headers=hd)

class Q(BaseModel):
    question: str

@app.post("/api/analyses/{aid}/ask")
def ask(aid: int, q: Q, u=Depends(user)):
    r = db().execute("SELECT * FROM analyses WHERE id=? AND (user_id=? OR (team IS NOT NULL AND team=?))", (aid, u["id"], u["team"])).fetchone()
    if not r: raise HTTPException(404, "Analyse introuvable")
    q.question = q.question[:500]; S = json.loads(r["summary"])
    if os.getenv("ANTHROPIC_API_KEY"):
        try:
            return {"answer": call_ai(f"Question: {q.question}\nStatistiques: {json.dumps(for_ai(S))[:30000]}",
                    "Réponds dans la langue de la question, uniquement à partir des statistiques fournies. Dis si l'information manque.", 600), "source": "ai"}
        except Exception: pass
    hit = [(s["file"], c) for s in S for c in s["columns"] if c["name"].lower() in q.question.lower()]
    if not hit:
        return {"answer": "Moteur local : citez le nom d'une colonne (ex. « moyenne de ventes »). / Local engine: mention a column name.\n" + local_insights(S, "fr"), "source": "local"}
    f, c = hit[0]
    d = {k: c[k] for k in ("type", "missing", "mean", "median", "min", "max", "std", "outliers") if k in c}
    return {"answer": f"{c['name']} ({f}) : {json.dumps(d, ensure_ascii=False)}", "source": "local"}

@app.middleware("http")
async def secure(request, call_next):
    if int(request.headers.get("content-length") or 0) > MAX_BODY:
        return JSONResponse({"detail": "Requête trop volumineuse"}, 413)
    try: r = await call_next(request)
    except Exception: return JSONResponse({"detail": "Erreur interne"}, 500)
    if PROD: r.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
        "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'"})
    return r

@app.get("/")
def index(): return FileResponse("static/index.html")
@app.get("/sw.js")
def sw(): return FileResponse("static/sw.js", media_type="text/javascript")
@app.get("/manifest.webmanifest")
def manifest(): return FileResponse("static/manifest.webmanifest", media_type="application/manifest+json")
@app.get("/icon-{size}.png")
def icon(size: int):
    if size not in (192, 512): raise HTTPException(404)
    return FileResponse(f"static/icon-{size}.png")
