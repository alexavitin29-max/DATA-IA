# DATA IA

Plateforme d'analyse de fichiers CSV/Excel : import, nettoyage, statistiques, graphiques, questions, rapports (HTML/CSV/XLSX/PDF), historique. FastAPI + SQLite, interface FR/EN, installable (PWA).

## Fonctionnalités
- Comptes, connexion limitée à 5 essais/5 min, quotas **côté serveur** (réinitialisation mensuelle, une analyse échouée n'est pas comptée).
- Analyse locale gratuite (pandas) : doublons, manquants, médiane, valeurs atypiques (IQR), corrélations, histogrammes. Chaque résultat indique sa source : « IA » seulement si Claude a répondu, sinon « statistique locale ».
- Nettoyage (doublons, espaces, nombres écrits en texte, remplissage) exporté en CSV ou XLSX, limité en taille et en fréquence.
- Questions sur les données (IA si clé, sinon réponse locale par nom de colonne).
- Équipe Business : historique partagé via un code secret aléatoire.

## Forfaits (tous facultatifs)
| | Free | Pro | Business |
|---|---|---|---|
| Analyses/mois | 3 | 100 | 1000 |
| Fichier max | 2 Mo | 25 Mo | 100 Mo |
| Fichiers/analyse | 1 | 1 | 10 |
| Nettoyages/heure | 10 | 60 | 200 |
| Historique | 10 | 50 | 50 + équipe |

Le forfait n'est modifiable que par le webhook Stripe signé. **Sans Stripe configuré, aucun paiement n'est simulé** : les boutons renvoient « fonction non configurée ».

## Installation et lancement
Prérequis : Python 3.11+.
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env     # puis exporter les variables (ou utiliser Docker)
uvicorn app:app --reload # http://localhost:8000
pytest -q tests
```
Vérification de cette version : `PYTHONPATH=. pytest -q` — **26 tests réussis** dans l'environnement de contrôle. Selon votre environnement, utilisez `python -m pytest -q` si la commande `pytest` ne trouve pas `app.py`.

## IA (optionnelle, payante côté fournisseur)
Renseignez `ANTHROPIC_API_KEY` côté serveur uniquement. Seules des statistiques agrégées sont envoyées (jamais les cellules, ni l'e-mail). Sans clé ou en cas d'échec, le moteur local prend le relais et l'interface l'indique.

## Sécurité
scrypt + sel, JWT 7 jours, taille de requête limitée (110 Mo) et par forfait, contrôle de signature des .xlsx et limite de décompression, rejet des CSV binaires, neutralisation des formules (=,+,-,@) dans les exports, CSP/HSTS, erreurs 500 génériques, isolation par utilisateur sur chaque route, code d'équipe aléatoire limité en essais. Limites connues : jeton stocké en localStorage (préférer un cookie httpOnly), limiteurs en mémoire (un seul processus ; utiliser Redis pour plusieurs), pas de vérification e-mail ni de réinitialisation de mot de passe, pas d'antivirus.

## Déploiement HTTPS
`ENV=production` + `SECRET_KEY` + `DOMAIN` dans `.env`, puis `docker compose up -d` : Caddy obtient le certificat HTTPS automatiquement. Le volume `/data` conserve SQLite : sur un hébergeur à disque éphémère, les données seraient perdues (utiliser un volume ou PostgreSQL). Vérifiez les conditions actuelles des offres gratuites des hébergeurs.
Stripe : 2 prix récurrents, webhook `/api/billing/webhook` (`checkout.session.completed`, `customer.subscription.deleted`).

## Android
- **PWA (gratuit, déjà prêt)** : ouvrez le site en HTTPS dans Chrome Android → « Installer l'application ». Manifest, service worker (l'API n'est jamais mise en cache) et icônes provisoires (carrés bleus à remplacer) sont fournis.
- **APK (non généré)** : `android/capacitor.config.json` est prêt pour Capacitor (`npm i @capacitor/core @capacitor/cli @capacitor/android`, `npx cap add android`, ouvrir dans Android Studio). L'URL du serveur HTTPS est obligatoire car le backend ne tourne pas dans le téléphone. Android Studio est gratuit ; publier sur Google Play coûte des frais uniques.

## Notes de version — correctifs DATA IA
- Le webhook Stripe répond maintenant proprement avec une erreur 400 si Stripe n'est pas configuré ou si la signature est invalide.
- La clé de développement par défaut a été allongée pour éviter les avertissements JWT. En production, définissez impérativement une clé secrète forte et unique.
- Les tests utilisent une base SQLite temporaire isolée ; les comptes créés lors d'une exécution ne polluent plus les tests suivants.
- Interface affinée : en-tête fixe translucide, cartes plus lisibles, interactions au survol, tableaux plus clairs et adaptation mobile renforcée.

## Limites actuelles
Pas d'application mobile native, pas de réinitialisation de mot de passe, pas de compte e-mail vérifié, historique des analyses sans suppression, pas de limitation d'inscription par IP.
